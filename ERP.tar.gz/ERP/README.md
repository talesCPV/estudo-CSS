# estudo-CSS

A idéia é criar uma barra de navegação superior no seguinte estilo:
  Barra fixa no topo da tela e sempre visível, independente da rolagem do conteúdo da pág
  O Menu ficará escondido abaixo de um ícone do lado esquerdo da barra (estilo Menu Iniciar), e ao passar o mouse sobre ele o menu desce mostrando apenas os ítem principais e escondendo os sub itens
  No centro da barra haverá um relógio com a data e hora atual
  No lado direito da barra teremos o nome do usuário acompanhado de icones de configuração e mensagens (span n. de msg)
