
    <link rel="stylesheet" type="text/css" href="css/upbar.css" media="screen" /> 
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="js/jqFunc.js"></script>
    
    <div class="upbar">
    	<div class="left_bar">
            <img src="img/fb.png" class="imgMenu" id="btnIniciar">

            <nav class="main_menu">
                <ul><input type="text" id="edtBusca" placeholder="Pesquisa"></ul>
                <?php
                    $json_file = file_get_contents("inc/bar/menu.json");
                    $json_str = json_decode($json_file, true);
                    foreach ( $json_str['sessoes'] as $e ) {
                        $modulo = $e['modulo'];
                        $link = $e['link'];
                        $icone = $e['icone'];
                        $id = $e['id'];
                        $perm = $e['perm'];
                        $itens = $e['itens'];

                        if(count($itens) > 0){
                            echo('<ul> <i class="'. $icone.' fl"></i>'. $modulo .'<i class="fr"> > </i>');
                                echo('<div class="Itens">');
                            foreach ($itens as $subitem) {
                                echo('<li id="'. $subitem['id'] .'">   '. $subitem['nome'] .'</li>');
                            }                         
                            echo('</div>');
                        } else {
                            echo('<ul> <i class="'. $icone.' fl"></i>'. $modulo .'<i class="fr"></i>');

                        }
                        echo('</ul>');
                    }

                ?>
	        </nav>

        </div>
        <div class="center_bar">
        	<a href="#">00:00</a>
        </div>
        <div class="right_bar">
        	<a href="#">username</a>
        </div>
    </div>